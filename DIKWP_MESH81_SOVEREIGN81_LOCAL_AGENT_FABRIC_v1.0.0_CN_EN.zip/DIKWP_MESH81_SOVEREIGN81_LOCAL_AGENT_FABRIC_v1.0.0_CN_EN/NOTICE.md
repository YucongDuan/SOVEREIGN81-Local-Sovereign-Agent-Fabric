# NOTICE

SOVEREIGN81 does not include or redistribute Muse Glimmer, Qwen, Gemma, Llama, or any other model weights.
Model names are interoperability profile labels and remain trademarks of their respective owners.
The included deterministic scripted model is for system verification only and is not a capability benchmark of those models.
