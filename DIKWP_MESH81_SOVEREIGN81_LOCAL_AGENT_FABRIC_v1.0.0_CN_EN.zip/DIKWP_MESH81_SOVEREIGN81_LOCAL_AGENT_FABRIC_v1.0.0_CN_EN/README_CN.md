# SOVEREIGN81：本地主权智能体织体

Muse Glimmer、Qwen、Gemma 或任何本地模型在本系统中都只是**可替换的提案引擎**。它们不能自行取得文件、网络、设备或外部账户的行动权。

## 核心管道

```
用户意图/价值 → 追加式 DIKWP 账本 → 模型提案 → W 策略决定
→ 单动作能力租约 → 影子执行 → 真实执行 → 结果回返 → 可逆/可理解交付
```

## 关键特征

- D/I/K/W/P 五元追加式记录；
- 二十五类路径全部可登记；
- 网络默认关闭，工作区路径限制；
- 模型只提出动作，策略才授予一次性能力租约；
- 写操作先影子模拟，并返回回滚令牌；
- 工具失败必须进入 I；相同盲重试会被阻止；
- 上下文可压缩，但账本不可静默删除；
- 模型可替换，任务连续性保存在模型外；
- 基准不输出总分，只输出治理证据向量。

## 快速开始

```bash
python -m venv .venv
. .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e .
sovereign81 demo --output demo_run
sovereign81 benchmark --output benchmark_run
sovereign81 verify-ledger demo_run/ledger.jsonl
```

直接打开 `OPEN_DASHBOARD.html` 查看离线展示系统。

## 连接本地模型

先用 vLLM、SGLang、llama.cpp、Ollama 兼容层等启动 OpenAI-compatible endpoint，然后：

```bash
sovereign81 run examples/task.json \
  --workspace ./workspace \
  --ledger ./run/ledger.jsonl \
  --base-url http://127.0.0.1:8000/v1 \
  --model meta-models/Muse-Glimmer-30B \
  --profile profiles/muse_glimmer_30b.json
```

发行包不包含任何模型权重。脚本化模型只用于验证运行时，不代表 Muse Glimmer 的实际能力测试。
