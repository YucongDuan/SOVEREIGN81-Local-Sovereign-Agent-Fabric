#!/usr/bin/env bash
set -euo pipefail
python -m sovereign81 demo --output demo_run
python -m sovereign81 benchmark --output benchmark_run
