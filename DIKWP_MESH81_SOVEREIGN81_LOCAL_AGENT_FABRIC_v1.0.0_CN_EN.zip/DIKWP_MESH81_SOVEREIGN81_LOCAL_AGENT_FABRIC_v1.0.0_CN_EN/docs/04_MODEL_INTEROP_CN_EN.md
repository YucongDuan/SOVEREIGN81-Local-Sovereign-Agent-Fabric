# Model Interoperability / 模型互操作

Any OpenAI-compatible local endpoint can serve as proposal engine. Profiles are included for Muse Glimmer and Qwen3.6-27B. Model-specific reasoning settings remain outside the authority layer. Swapping models does not rewrite the ledger or capability policy.
