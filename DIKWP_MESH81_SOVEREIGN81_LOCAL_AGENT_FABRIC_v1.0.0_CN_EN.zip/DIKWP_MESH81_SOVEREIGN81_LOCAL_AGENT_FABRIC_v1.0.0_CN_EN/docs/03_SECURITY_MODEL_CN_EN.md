# Security Model / 安全模型

Default guarantees are narrow and testable: no network tool, no arbitrary shell, workspace confinement, one-action leases, reversible writes, hash-chained ledger, and blocked blind retries. They do not constitute a complete operating-system sandbox. Production deployment should add OS-level isolation, filesystem ACLs, secret brokers, signed tool manifests, and human confirmation for high-impact actions.
