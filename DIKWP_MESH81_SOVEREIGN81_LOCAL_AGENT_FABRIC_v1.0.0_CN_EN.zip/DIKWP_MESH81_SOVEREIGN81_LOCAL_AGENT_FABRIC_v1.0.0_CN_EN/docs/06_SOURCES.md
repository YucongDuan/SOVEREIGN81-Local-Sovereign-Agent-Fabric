# Primary sources

- Meta AI Research, “Introducing Muse Glimmer: An Open Agentic Model That Runs on Your Device,” 2026-08-10.
- Meta model card, `meta-models/Muse-Glimmer-30B`, Hugging Face.
- Meta, “Muse Glimmer Evaluation Methodology,” 2026.
- Chen et al., “DFlash: Block Diffusion for Flash Speculative Decoding,” arXiv:2602.06036.
- Bolya et al., “Perception Encoder,” arXiv:2504.13181.
- Qwen Team, `Qwen/Qwen3.6-27B` model card, 2026.
