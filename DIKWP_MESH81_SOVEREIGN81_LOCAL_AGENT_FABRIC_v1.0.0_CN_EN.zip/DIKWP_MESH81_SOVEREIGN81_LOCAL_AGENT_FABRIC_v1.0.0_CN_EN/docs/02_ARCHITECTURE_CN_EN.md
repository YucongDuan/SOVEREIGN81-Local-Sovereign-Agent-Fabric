# Architecture / 架构

SOVEREIGN81 separates seven authorities:

1. User intent and values.
2. Append-only D/I/K/W/P ledger.
3. Replaceable model proposal.
4. W-policy decision.
5. One-action capability lease.
6. Shadow and real execution.
7. Reconciliation, rollback, and understanding.

The model never writes directly to the workspace. The runtime executes only after policy authorization and shadow inspection. Context compaction is a view over immutable history, not deletion of history.
