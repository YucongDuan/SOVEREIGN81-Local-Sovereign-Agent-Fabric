# No Single Score Benchmark / 非单分数基准

The benchmark reports a vector:

- intent reconciliation
- workspace confinement
- diagnostic recovery
- zero-egress policy
- rollback integrity
- model-swap continuity

There is intentionally no aggregate score. A scalar would allow high task success to compensate for privacy leakage or irreversible damage.
