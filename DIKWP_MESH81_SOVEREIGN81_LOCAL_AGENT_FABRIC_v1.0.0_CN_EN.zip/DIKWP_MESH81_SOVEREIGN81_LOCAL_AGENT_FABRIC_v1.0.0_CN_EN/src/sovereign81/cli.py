from __future__ import annotations
import argparse
import json
from pathlib import Path
from .benchmark import run_benchmark
from .dashboard import build_dashboard
from .ledger import SemanticLedger
from .models import OpenAICompatibleModel, ScriptedModel
from .policy import LocalStrictPolicy
from .records import ROUTES, Task
from .runtime import SovereignRuntime


def load_json(path: str | Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="sovereign81", description="DIKWP-MESH8.1 local sovereign agent fabric")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("routes")
    p_verify = sub.add_parser("verify-ledger")
    p_verify.add_argument("ledger")

    p_demo = sub.add_parser("demo")
    p_demo.add_argument("--output", default="demo_run")

    p_bench = sub.add_parser("benchmark")
    p_bench.add_argument("--output", default="benchmark_run")

    p_run = sub.add_parser("run")
    p_run.add_argument("task")
    p_run.add_argument("--workspace", required=True)
    p_run.add_argument("--ledger", required=True)
    p_run.add_argument("--base-url", required=True)
    p_run.add_argument("--model", required=True)
    p_run.add_argument("--profile")

    args = parser.parse_args(argv)

    if args.command == "routes":
        print(json.dumps({"count": len(ROUTES), "routes": ROUTES}, ensure_ascii=False, indent=2))
        return 0
    if args.command == "verify-ledger":
        print(json.dumps(SemanticLedger(args.ledger).verify(), ensure_ascii=False, indent=2))
        return 0
    if args.command == "benchmark":
        print(json.dumps(run_benchmark(args.output), ensure_ascii=False, indent=2))
        return 0
    if args.command == "demo":
        out = Path(args.output)
        ws = out / "workspace"
        (ws / "inputs").mkdir(parents=True, exist_ok=True)
        (ws / "inputs" / "brief.txt").write_text("Muse Glimmer is a proposal engine; user policy remains authoritative.\n", encoding="utf-8")
        proposals = [
            {"action": "read_text", "arguments": {"path": "inputs/brief-v2.txt"}, "rationale": "try the anticipated source name"},
            {"action": "read_text", "arguments": {"path": "inputs/brief.txt"}, "rationale": "recover by using the observed existing file", "recovery_basis": "the first tool result reported NOT_FOUND for brief-v2.txt"},
            {"action": "write_text", "arguments": {"path": "outputs/report.md", "text": "# Sovereign local agent\n\nModel proposes. Policy authorizes. Ledger remembers. Actions remain reversible.\n"}, "rationale": "create an auditable local artifact", "expected": {"path": "outputs/report.md"}},
            {"action": "finish", "arguments": {}, "rationale": "deliverable created", "finish": True},
        ]
        runtime = SovereignRuntime(workspace=ws, ledger_path=out / "ledger.jsonl", model=ScriptedModel(proposals, name="muse-glimmer-compatible-mock"))
        summary = runtime.run(Task("DEMO-001", "Create a local, auditable sovereignty note", {"source": "inputs/brief.txt"}, {"network": "deny", "reversible": True}))
        (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    if args.command == "run":
        task_data = load_json(args.task)
        profile = load_json(args.profile) if args.profile else {}
        model = OpenAICompatibleModel(base_url=args.base_url, model=args.model, profile=profile)
        runtime = SovereignRuntime(workspace=args.workspace, ledger_path=args.ledger, model=model, policy=LocalStrictPolicy(task_data.get("policy")))
        result = runtime.run(Task(task_data["task_id"], task_data["intent"], task_data.get("inputs", {}), task_data.get("values", {})))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    return 2
