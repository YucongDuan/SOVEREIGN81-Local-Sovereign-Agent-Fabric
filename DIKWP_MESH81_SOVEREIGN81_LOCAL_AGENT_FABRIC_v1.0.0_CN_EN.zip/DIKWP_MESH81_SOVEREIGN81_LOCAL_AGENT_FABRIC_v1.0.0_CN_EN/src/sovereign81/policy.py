from __future__ import annotations
from dataclasses import asdict
from pathlib import PurePosixPath
from typing import Any
from .canonical import short_digest
from .records import CapabilityLease, PolicyDecision, Proposal


class LocalStrictPolicy:
    """W-position policy: local-first, least privilege, reversible-by-default."""

    def __init__(self, config: dict[str, Any] | None = None):
        cfg = config or {}
        self.allowed_tools = tuple(cfg.get("allowed_tools", ["list_files", "read_text", "write_text", "restore", "calculate"]))
        self.path_prefixes = tuple(cfg.get("path_prefixes", [".", "inputs", "outputs"]))
        self.network_allowed = bool(cfg.get("network_allowed", False))
        self.irreversible_allowed = bool(cfg.get("irreversible_allowed", False))
        self.max_actions = int(cfg.get("max_actions", 12))
        self.require_shadow = bool(cfg.get("require_shadow", True))
        self.require_human_for_irreversible = bool(cfg.get("require_human_for_irreversible", True))

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed_tools": list(self.allowed_tools),
            "path_prefixes": list(self.path_prefixes),
            "network_allowed": self.network_allowed,
            "irreversible_allowed": self.irreversible_allowed,
            "max_actions": self.max_actions,
            "require_shadow": self.require_shadow,
            "require_human_for_irreversible": self.require_human_for_irreversible,
        }

    def decide(self, proposal: Proposal, *, step: int) -> PolicyDecision:
        if proposal.finish:
            return PolicyDecision(True, "FINISH", "model requested completion", None)
        if proposal.action not in self.allowed_tools:
            return PolicyDecision(False, "TOOL_NOT_ALLOWED", f"tool not in W-policy: {proposal.action}")
        if proposal.action == "network_request" and not self.network_allowed:
            return PolicyDecision(False, "NETWORK_EGRESS_DENIED", "local-strict W forbids network egress")
        if step >= self.max_actions:
            return PolicyDecision(False, "ACTION_BUDGET_EXHAUSTED", "maximum action count reached")
        path = proposal.arguments.get("path")
        if path is not None:
            normalized = str(PurePosixPath(str(path)))
            if normalized.startswith("../") or normalized == ".." or normalized.startswith("/"):
                return PolicyDecision(False, "PATH_SCOPE_DENIED", f"path outside lease scope: {path}")
        lease_payload = {
            "tool": proposal.action,
            "paths": self.path_prefixes,
            "step": step,
            "max_actions": self.max_actions,
        }
        lease = CapabilityLease(
            lease_id=f"L-{short_digest(lease_payload)}",
            tools=(proposal.action,),
            path_prefixes=self.path_prefixes,
            max_actions=1,
            network_allowed=self.network_allowed,
            irreversible_allowed=self.irreversible_allowed,
            expires_step=step,
        )
        return PolicyDecision(True, "LEASE_GRANTED", "least-privilege one-action lease", lease)
