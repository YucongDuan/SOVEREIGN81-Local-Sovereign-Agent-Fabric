from __future__ import annotations
import hashlib
from pathlib import Path
from typing import Any
from .records import ExecutionResult
from .safeexpr import evaluate


class ToolError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


class LocalToolRegistry:
    """A deliberately small, reversible, workspace-confined tool set."""

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _resolve(self, relative: str) -> Path:
        candidate = (self.workspace / relative).resolve()
        try:
            candidate.relative_to(self.workspace)
        except ValueError as exc:
            raise ToolError("PATH_ESCAPE", f"path escapes workspace: {relative}") from exc
        return candidate

    def schema(self) -> dict[str, Any]:
        return {
            "list_files": {"path": "relative directory"},
            "read_text": {"path": "relative file"},
            "write_text": {"path": "relative file", "text": "content"},
            "restore": {"rollback_token": "token returned by write_text"},
            "calculate": {"expression": "safe arithmetic expression"},
            "network_request": {"url": "always denied by local-strict policy"},
        }

    def simulate(self, tool: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if tool == "write_text":
            path = self._resolve(str(arguments.get("path", "")))
            before = path.read_text(encoding="utf-8") if path.exists() else None
            after = str(arguments.get("text", ""))
            return {
                "tool": tool,
                "path": str(path.relative_to(self.workspace)),
                "would_create": before is None,
                "before_sha256": hashlib.sha256((before or "").encode()).hexdigest(),
                "after_sha256": hashlib.sha256(after.encode()).hexdigest(),
                "characters_before": len(before or ""),
                "characters_after": len(after),
                "reversible": True,
            }
        if tool == "read_text":
            path = self._resolve(str(arguments.get("path", "")))
            return {"tool": tool, "path": str(path.relative_to(self.workspace)), "exists": path.exists(), "reversible": True}
        if tool == "list_files":
            path = self._resolve(str(arguments.get("path", ".")))
            return {"tool": tool, "path": str(path.relative_to(self.workspace)), "exists": path.exists(), "reversible": True}
        if tool == "calculate":
            return {"tool": tool, "expression": str(arguments.get("expression", "")), "reversible": True}
        if tool == "restore":
            return {"tool": tool, "reversible": True}
        if tool == "network_request":
            return {"tool": tool, "network": True, "reversible": False}
        raise ToolError("UNKNOWN_TOOL", tool)

    def execute(self, tool: str, arguments: dict[str, Any]) -> ExecutionResult:
        try:
            if tool == "list_files":
                path = self._resolve(str(arguments.get("path", ".")))
                if not path.exists() or not path.is_dir():
                    raise ToolError("NOT_DIRECTORY", str(arguments.get("path", ".")))
                rows = []
                for item in sorted(path.iterdir()):
                    rows.append({"name": item.name, "kind": "directory" if item.is_dir() else "file", "bytes": item.stat().st_size if item.is_file() else None})
                return ExecutionResult(True, tool, {"entries": rows}, True)

            if tool == "read_text":
                path = self._resolve(str(arguments["path"]))
                if not path.exists() or not path.is_file():
                    raise ToolError("NOT_FOUND", str(arguments["path"]))
                text = path.read_text(encoding="utf-8")
                return ExecutionResult(True, tool, {"path": str(path.relative_to(self.workspace)), "text": text, "sha256": hashlib.sha256(text.encode()).hexdigest()}, True)

            if tool == "write_text":
                path = self._resolve(str(arguments["path"]))
                before_exists = path.exists()
                before = path.read_text(encoding="utf-8") if before_exists else ""
                path.parent.mkdir(parents=True, exist_ok=True)
                text = str(arguments.get("text", ""))
                path.write_text(text, encoding="utf-8")
                token = {"path": str(path.relative_to(self.workspace)), "before_exists": before_exists, "before": before}
                return ExecutionResult(True, tool, {"path": token["path"], "characters": len(text), "sha256": hashlib.sha256(text.encode()).hexdigest()}, True, token)

            if tool == "restore":
                token = arguments["rollback_token"]
                path = self._resolve(str(token["path"]))
                if token.get("before_exists"):
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(str(token.get("before", "")), encoding="utf-8")
                elif path.exists():
                    path.unlink()
                return ExecutionResult(True, tool, {"restored": str(path.relative_to(self.workspace))}, True)

            if tool == "calculate":
                expression = str(arguments["expression"])
                return ExecutionResult(True, tool, {"expression": expression, "value": evaluate(expression)}, True)

            if tool == "network_request":
                raise ToolError("NETWORK_TOOL_DISABLED", "network tool is intentionally unavailable")

            raise ToolError("UNKNOWN_TOOL", tool)
        except (KeyError, ToolError, ValueError, OSError) as exc:
            code = exc.code if isinstance(exc, ToolError) else "TOOL_ERROR"
            return ExecutionResult(False, tool, {}, True, error_code=code, error_message=str(exc))
