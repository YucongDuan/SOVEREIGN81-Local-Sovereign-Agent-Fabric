from __future__ import annotations
from typing import Any
from .tools import LocalToolRegistry, ToolError


def shadow(tool_registry: LocalToolRegistry, action: str, arguments: dict[str, Any]) -> dict[str, Any]:
    try:
        preview = tool_registry.simulate(action, arguments)
        return {"ok": True, "preview": preview}
    except ToolError as exc:
        return {"ok": False, "error_code": exc.code, "error_message": str(exc)}
