from __future__ import annotations
from typing import Any
from .canonical import digest


def build_understanding_packet(*, task: dict[str, Any], events: list[dict[str, Any]], changed_paths: list[str]) -> dict[str, Any]:
    failures = [e for e in events if e["kind"] in {"ACTION_FAILED", "POLICY_DENIED", "BLIND_RETRY_BLOCKED"}]
    actions = [e for e in events if e["kind"] == "ACTION_EXECUTED"]
    return {
        "task_id": task["task_id"],
        "intent": task["intent"],
        "what_changed": changed_paths,
        "action_count": len(actions),
        "visible_differences": [e["payload"] for e in failures],
        "rollback_available": all(e["payload"].get("reversible", True) for e in actions),
        "model_authority": "proposal_only",
        "policy_authority": "W-position capability lease",
        "continuity": "external append-only ledger survives model swap",
        "packet_digest": digest({"task": task, "events": events, "paths": changed_paths}),
    }
