from __future__ import annotations
from typing import Any
from .canonical import digest


def metabolize(events: list[dict[str, Any]], *, max_events: int = 12) -> dict[str, Any]:
    """Create a bounded model view without deleting the append-only ledger."""
    selected = events[-max_events:]
    omitted = events[:-max_events]
    return {
        "selected_events": selected,
        "selected_count": len(selected),
        "omitted_count": len(omitted),
        "omitted_digest": digest(omitted),
        "full_event_count": len(events),
        "continuity_rule": "view_is_bounded; ledger_is_append_only",
    }
