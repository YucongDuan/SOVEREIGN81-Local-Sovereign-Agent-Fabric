from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Any
from .ledger import SemanticLedger
from .metabolism import metabolize
from .models import ProposalModel
from .policy import LocalStrictPolicy
from .records import Proposal, Task
from .simulator import shadow
from .tools import LocalToolRegistry
from .understanding import build_understanding_packet


class SovereignRuntime:
    """Proposal → W-policy → lease → shadow → execute → reconcile → understand."""

    def __init__(self, *, workspace: str | Path, ledger_path: str | Path, model: ProposalModel, policy: LocalStrictPolicy | None = None):
        self.tools = LocalToolRegistry(workspace)
        self.ledger = SemanticLedger(ledger_path)
        self.model = model
        self.policy = policy or LocalStrictPolicy()
        self._last_failure_signature: tuple[str, str] | None = None
        self._rollback_tokens: list[dict[str, Any]] = []
        self._changed_paths: list[str] = []

    def _record(self, position: str, route: str, kind: str, payload: dict[str, Any]) -> None:
        self.ledger.append(position=position, route=route, kind=kind, payload=payload)

    def run(self, task: Task) -> dict[str, Any]:
        self._record("D", "D>W", "TASK_RECEIVED", asdict(task))
        self._record("W", "W>P", "POLICY_BOUND", self.policy.to_dict())
        status = "RUNNING"

        for step in range(self.policy.max_actions + 1):
            events = self.ledger.events()
            view = metabolize(events)
            context = {
                "task": asdict(task),
                "step": step,
                "model": self.model.name,
                "policy": self.policy.to_dict(),
                "ledger_view": view,
                "tool_schema": self.tools.schema(),
            }
            self._record("K", "K>P", "CONTEXT_METABOLIZED", {"step": step, "omitted_count": view["omitted_count"], "omitted_digest": view["omitted_digest"]})
            proposal = self.model.propose(context)
            self._record("P", "P>W", "MODEL_PROPOSAL", {"model": self.model.name, **asdict(proposal)})

            if proposal.finish:
                status = "COMPLETED"
                self._record("P", "P>K", "MODEL_FINISH", {"step": step, "rationale": proposal.rationale})
                break

            signature = (proposal.action, repr(sorted(proposal.arguments.items())))
            if self._last_failure_signature == signature and not proposal.recovery_basis:
                self._record("I", "I>P", "BLIND_RETRY_BLOCKED", {"action": proposal.action, "arguments": proposal.arguments, "reason": "identical retry requires recovery_basis"})
                status = "BLOCKED"
                break

            decision = self.policy.decide(proposal, step=step)
            self._record("W", "W>P", "POLICY_DECISION", {"allowed": decision.allowed, "code": decision.code, "reason": decision.reason, "lease": asdict(decision.lease) if decision.lease else None})
            if not decision.allowed:
                self._record("I", "I>K", "POLICY_DENIED", {"action": proposal.action, "code": decision.code, "reason": decision.reason})
                self._last_failure_signature = signature
                status = "DENIED"
                break

            preview = shadow(self.tools, proposal.action, proposal.arguments)
            self._record("P", "P>D", "SHADOW_SIMULATION", preview)
            if not preview["ok"]:
                self._record("I", "I>P", "SHADOW_FAILED", preview)
                self._last_failure_signature = signature
                status = "FAILED"
                continue

            result = self.tools.execute(proposal.action, proposal.arguments)
            if result.ok:
                self._record("D", "D>K", "ACTION_EXECUTED", {"tool": result.tool, "output": result.output, "reversible": result.reversible, "lease_id": decision.lease.lease_id if decision.lease else None})
                self._last_failure_signature = None
                if result.rollback_token:
                    self._rollback_tokens.append(result.rollback_token)
                if result.tool == "write_text" and "path" in result.output:
                    self._changed_paths.append(result.output["path"])
                self._record("K", "K>D", "RECONCILED", {"expected": proposal.expected, "observed": result.output, "match_mode": "explicit_observation"})
            else:
                self._record("I", "I>P", "ACTION_FAILED", {"tool": result.tool, "error_code": result.error_code, "error_message": result.error_message})
                self._last_failure_signature = signature
                status = "FAILED"
        else:
            status = "ACTION_BUDGET_EXHAUSTED"

        packet = build_understanding_packet(task=asdict(task), events=self.ledger.events(), changed_paths=sorted(set(self._changed_paths)))
        self._record("K", "K>W", "UNDERSTANDING_PACKET", packet)
        verification = self.ledger.verify()
        counts = self.ledger.position_counts()
        closure = "".join("1" if counts[p] > 0 else "0" for p in ("D", "I", "K", "W", "P"))
        return {
            "status": status,
            "task_id": task.task_id,
            "model": self.model.name,
            "closure_vector": closure,
            "position_counts": counts,
            "changed_paths": sorted(set(self._changed_paths)),
            "rollback_tokens": self._rollback_tokens,
            "understanding_packet": packet,
            "ledger": verification,
        }

    def rollback_all(self) -> dict[str, Any]:
        results = []
        for token in reversed(self._rollback_tokens):
            result = self.tools.execute("restore", {"rollback_token": token})
            self._record("P", "P>D", "ROLLBACK_EXECUTED", {"ok": result.ok, "output": result.output})
            results.append(asdict(result))
        return {"ok": all(r["ok"] for r in results), "results": results, "ledger": self.ledger.verify()}
