from __future__ import annotations
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

Position = Literal["D", "I", "K", "W", "P"]
POSITIONS: tuple[Position, ...] = ("D", "I", "K", "W", "P")
ROUTES: tuple[str, ...] = tuple(f"{a}>{b}" for a in POSITIONS for b in POSITIONS)


@dataclass(frozen=True)
class Task:
    task_id: str
    intent: str
    inputs: dict[str, Any]
    values: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Proposal:
    action: str
    arguments: dict[str, Any]
    rationale: str
    expected: dict[str, Any] = field(default_factory=dict)
    recovery_basis: str | None = None
    finish: bool = False


@dataclass(frozen=True)
class CapabilityLease:
    lease_id: str
    tools: tuple[str, ...]
    path_prefixes: tuple[str, ...]
    max_actions: int
    network_allowed: bool
    irreversible_allowed: bool
    expires_step: int


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    code: str
    reason: str
    lease: CapabilityLease | None = None


@dataclass(frozen=True)
class ExecutionResult:
    ok: bool
    tool: str
    output: dict[str, Any]
    reversible: bool
    rollback_token: dict[str, Any] | None = None
    error_code: str | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class Event:
    index: int
    timestamp: str
    event_id: str
    position: Position
    route: str
    kind: str
    payload: dict[str, Any]
    previous_digest: str
    event_digest: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
