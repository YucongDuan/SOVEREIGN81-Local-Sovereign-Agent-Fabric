from __future__ import annotations
import json
import re
import urllib.request
from dataclasses import asdict
from typing import Any, Protocol
from .records import Proposal


class ProposalModel(Protocol):
    name: str
    def propose(self, context: dict[str, Any]) -> Proposal: ...


def extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    if start < 0 or end < start:
        raise ValueError("model response does not contain JSON")
    return json.loads(text[start:end + 1])


def proposal_from_dict(data: dict[str, Any]) -> Proposal:
    return Proposal(
        action=str(data.get("action", "finish")),
        arguments=dict(data.get("arguments", {})),
        rationale=str(data.get("rationale", "")),
        expected=dict(data.get("expected", {})),
        recovery_basis=data.get("recovery_basis"),
        finish=bool(data.get("finish", data.get("action") == "finish")),
    )


class ScriptedModel:
    def __init__(self, proposals: list[dict[str, Any]], name: str = "scripted-mock"):
        self.name = name
        self._proposals = [proposal_from_dict(p) for p in proposals]
        self._index = 0

    def propose(self, context: dict[str, Any]) -> Proposal:
        if self._index >= len(self._proposals):
            return Proposal("finish", {}, "script exhausted", finish=True)
        proposal = self._proposals[self._index]
        self._index += 1
        return proposal


class OpenAICompatibleModel:
    """Dependency-free adapter for a local OpenAI-compatible endpoint."""

    def __init__(self, *, base_url: str, model: str, api_key: str = "EMPTY", profile: dict[str, Any] | None = None):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.profile = profile or {}
        self.name = f"openai-compatible:{model}"

    def propose(self, context: dict[str, Any]) -> Proposal:
        tools = context.get("tool_schema", {})
        system = (
            self.profile.get("system_prefix", "")
            + "\nYou are a proposal engine, not an authority. Return one JSON object only. "
              "Fields: action, arguments, rationale, expected, recovery_basis, finish. "
              "Choose only a listed tool. Never claim an action occurred before the runtime executes it."
        ).strip()
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": json.dumps({"context": context, "tools": tools}, ensure_ascii=False)},
            ],
            "temperature": self.profile.get("temperature", 1.0),
            "top_p": self.profile.get("top_p", 0.95),
            "max_tokens": self.profile.get("max_tokens", 1200),
        }
        extra = self.profile.get("extra_body", {})
        body.update(extra)
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=float(self.profile.get("timeout", 120))) as response:
            payload = json.loads(response.read().decode("utf-8"))
        text = payload["choices"][0]["message"]["content"]
        return proposal_from_dict(extract_json(text))
