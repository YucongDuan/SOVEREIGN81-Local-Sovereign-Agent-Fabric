from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from .canonical import digest
from .records import Event, POSITIONS, ROUTES

GENESIS_DIGEST = "0" * 64


class LedgerIntegrityError(RuntimeError):
    pass


class SemanticLedger:
    """Append-only DIKWP ledger with a deterministic hash chain."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("", encoding="utf-8")

    def events(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                out.append(json.loads(line))
        return out

    def append(self, *, position: str, route: str, kind: str, payload: dict[str, Any]) -> Event:
        if position not in POSITIONS:
            raise ValueError(f"invalid position: {position}")
        if route not in ROUTES:
            raise ValueError(f"invalid route: {route}")
        current = self.events()
        index = len(current)
        prev = current[-1]["event_digest"] if current else GENESIS_DIGEST
        timestamp = datetime.now(timezone.utc).isoformat()
        body = {
            "index": index,
            "timestamp": timestamp,
            "event_id": f"E{index:06d}",
            "position": position,
            "route": route,
            "kind": kind,
            "payload": payload,
            "previous_digest": prev,
        }
        body["event_digest"] = digest(body)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(body, ensure_ascii=False, sort_keys=True) + "\n")
        return Event(**body)

    def verify(self) -> dict[str, Any]:
        events = self.events()
        prev = GENESIS_DIGEST
        for idx, ev in enumerate(events):
            if ev.get("index") != idx:
                raise LedgerIntegrityError(f"index mismatch at {idx}")
            if ev.get("previous_digest") != prev:
                raise LedgerIntegrityError(f"previous digest mismatch at {idx}")
            copy = dict(ev)
            claimed = copy.pop("event_digest", None)
            actual = digest(copy)
            if claimed != actual:
                raise LedgerIntegrityError(f"event digest mismatch at {idx}")
            if ev.get("position") not in POSITIONS or ev.get("route") not in ROUTES:
                raise LedgerIntegrityError(f"semantic marker mismatch at {idx}")
            prev = claimed
        return {
            "ok": True,
            "event_count": len(events),
            "head_digest": prev,
            "positions_seen": sorted({e["position"] for e in events}),
            "routes_seen": sorted({e["route"] for e in events}),
        }

    def position_counts(self) -> dict[str, int]:
        counts = {p: 0 for p in POSITIONS}
        for event in self.events():
            counts[event["position"]] += 1
        return counts

    def select(self, kinds: Iterable[str] | None = None) -> list[dict[str, Any]]:
        events = self.events()
        if kinds is None:
            return events
        wanted = set(kinds)
        return [e for e in events if e["kind"] in wanted]
