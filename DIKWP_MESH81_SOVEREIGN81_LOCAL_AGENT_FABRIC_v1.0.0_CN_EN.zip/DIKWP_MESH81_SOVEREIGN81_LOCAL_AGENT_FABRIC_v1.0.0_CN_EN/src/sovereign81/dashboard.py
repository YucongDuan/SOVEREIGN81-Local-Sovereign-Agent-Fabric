from __future__ import annotations
import html
import json
from pathlib import Path
from typing import Any


def build_dashboard(*, demo_summary: dict[str, Any], benchmark: dict[str, Any], output: str | Path) -> None:
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    vector = benchmark["evidence_vector"]
    cards = "".join(
        f'<article class="card"><span class="dot {"ok" if ok else "bad"}"></span><h3>{html.escape(name.replace("_", " ").title())}</h3><p>{"PASS" if ok else "OPEN"}</p></article>'
        for name, ok in vector.items()
    )
    counts = demo_summary["position_counts"]
    positions = "".join(f'<div class="position"><b>{p}</b><span>{counts[p]}</span></div>' for p in "DIKWP")
    data = json.dumps({"demo": demo_summary, "benchmark": benchmark}, ensure_ascii=False).replace("</", "<\\/")
    page = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SOVEREIGN81 Local Agent Fabric</title>
<style>
:root{{--bg:#07111f;--panel:#0d1b2d;--text:#eef6ff;--muted:#9bb0c8;--accent:#64d8cb;--accent2:#ffbc66;--bad:#ff6b7a}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 15% 10%,#15334b 0,#07111f 38%,#030812 100%);color:var(--text);font-family:Inter,"Noto Sans SC",system-ui,sans-serif;line-height:1.55}}
header{{min-height:72vh;padding:7vw;display:flex;flex-direction:column;justify-content:center;border-bottom:1px solid #28415d}}
.eyebrow{{color:var(--accent);letter-spacing:.18em;font-weight:700}}h1{{font-size:clamp(3rem,8vw,7rem);line-height:.92;margin:.3em 0;max-width:1100px}}h1 span{{color:var(--accent2)}}.lead{{max-width:900px;font-size:1.25rem;color:var(--muted)}}
main{{max-width:1250px;margin:auto;padding:4rem 2rem}}section{{margin:4rem 0}}h2{{font-size:2.2rem;margin-bottom:.5rem}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:1rem}}.card{{background:linear-gradient(150deg,#10243a,#0a1524);border:1px solid #29435e;border-radius:18px;padding:1.2rem;min-height:145px}}.dot{{display:inline-block;width:12px;height:12px;border-radius:50%;background:var(--bad)}}.dot.ok{{background:var(--accent);box-shadow:0 0 18px var(--accent)}}.positions{{display:grid;grid-template-columns:repeat(5,1fr);gap:1rem}}.position{{border:1px solid #2c4966;border-radius:999px;padding:1rem;text-align:center;background:#0b192a}}.position b{{font-size:1.8rem;color:var(--accent2)}}.position span{{display:block;color:var(--muted)}}
.pipeline{{display:grid;grid-template-columns:repeat(7,1fr);gap:.7rem}}.stage{{padding:1rem .6rem;border-radius:14px;text-align:center;background:#10243a;border:1px solid #31506f}}pre{{white-space:pre-wrap;background:#02060d;border:1px solid #263d57;border-radius:16px;padding:1rem;color:#bfeee8;overflow:auto}}footer{{padding:3rem 2rem;color:var(--muted);text-align:center}}
@media(max-width:850px){{.pipeline{{grid-template-columns:1fr 1fr}}.positions{{grid-template-columns:repeat(2,1fr)}}}}
</style></head><body>
<header><div class="eyebrow">DIKWP-MESH8.1 · OPEN SOURCE · MODEL INDEPENDENT</div><h1>LOCAL MODEL IS NOT <span>LOCAL SOVEREIGNTY</span></h1><p class="lead">SOVEREIGN81 把 Muse Glimmer、Qwen 或任何本地模型降为可替换的提案引擎，把用户意图、价值边界、能力租约、影子执行、可逆行动、差异记录与模型切换连续性置于模型之外。</p></header>
<main>
<section><h2>五元运行记录</h2><p>演示闭合向量：<strong>{demo_summary['closure_vector']}</strong>。它只表示五类记录均出现，不代表模型获得行动主权。</p><div class="positions">{positions}</div></section>
<section><h2>主权行动管道</h2><div class="pipeline"><div class="stage">用户意图</div><div class="stage">模型提案</div><div class="stage">W 策略</div><div class="stage">能力租约</div><div class="stage">影子执行</div><div class="stage">真实执行</div><div class="stage">回返/理解</div></div></section>
<section><h2>非单分数治理向量</h2><p>系统拒绝把安全、效用、可逆性和连续性压成一个总分。</p><div class="grid">{cards}</div></section>
<section><h2>演示摘要</h2><pre>{html.escape(json.dumps(demo_summary, ensure_ascii=False, indent=2))}</pre></section>
<section><h2>运行边界</h2><div class="grid"><article class="card"><h3>无模型权重</h3><p>发行包不分发 Muse 或 Qwen 权重。</p></article><article class="card"><h3>无任意 Shell</h3><p>默认工具集不暴露通用命令执行。</p></article><article class="card"><h3>网络默认关闭</h3><p>“本地”由策略与工具边界实现，而不是模型自称。</p></article><article class="card"><h3>追加式账本</h3><p>上下文可压缩，语义历史不可被静默删除。</p></article></div></section>
</main><footer>SOVEREIGN81 v1.0.0 · Apache-2.0 · Data object embedded for offline inspection</footer>
<script>window.SOVEREIGN81_DATA={data};</script></body></html>"""
    out.write_text(page, encoding="utf-8")
