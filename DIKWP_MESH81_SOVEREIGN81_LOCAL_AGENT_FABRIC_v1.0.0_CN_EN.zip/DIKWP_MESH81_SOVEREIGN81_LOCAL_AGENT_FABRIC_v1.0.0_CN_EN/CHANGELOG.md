# Changelog

## 1.0.0 - 2026-08-10

- Initial model-independent local sovereign agent fabric.
- Append-only DIKWP ledger and 25-route vocabulary.
- Capability leases, shadow execution, reversible workspace tools.
- Failure visibility, blind-retry guard, context metabolism, model-swap continuity.
- Non-scalar governance benchmark and offline dashboard.
