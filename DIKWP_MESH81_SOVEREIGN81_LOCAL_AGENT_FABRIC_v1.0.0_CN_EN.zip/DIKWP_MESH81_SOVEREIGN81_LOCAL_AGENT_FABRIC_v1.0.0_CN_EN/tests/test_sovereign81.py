from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path
from sovereign81.benchmark import run_benchmark
from sovereign81.ledger import LedgerIntegrityError, SemanticLedger
from sovereign81.models import extract_json, ScriptedModel
from sovereign81.records import ROUTES, Task
from sovereign81.runtime import SovereignRuntime
from sovereign81.safeexpr import UnsafeExpression, evaluate
from sovereign81.tools import LocalToolRegistry


class SovereignTests(unittest.TestCase):
    def test_routes_complete(self):
        self.assertEqual(len(ROUTES), 25)
        self.assertIn("D>D", ROUTES)
        self.assertIn("P>P", ROUTES)

    def test_safe_calc(self):
        self.assertEqual(evaluate("2+3*4"), 14)
        with self.assertRaises(UnsafeExpression):
            evaluate("__import__('os').system('id')")

    def test_path_escape_denied(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = LocalToolRegistry(tmp).execute("read_text", {"path": "../x"})
            self.assertFalse(result.ok)
            self.assertEqual(result.error_code, "PATH_ESCAPE")

    def test_write_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            reg = LocalToolRegistry(tmp)
            result = reg.execute("write_text", {"path": "a.txt", "text": "x"})
            self.assertTrue(result.ok)
            restore = reg.execute("restore", {"rollback_token": result.rollback_token})
            self.assertTrue(restore.ok)
            self.assertFalse((Path(tmp)/"a.txt").exists())

    def test_ledger_integrity_and_tamper(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/"l.jsonl"
            ledger = SemanticLedger(path)
            ledger.append(position="D", route="D>K", kind="X", payload={"x":1})
            self.assertTrue(ledger.verify()["ok"])
            rows = path.read_text().splitlines()
            obj = json.loads(rows[0]); obj["payload"]["x"] = 2
            path.write_text(json.dumps(obj)+"\n")
            with self.assertRaises(LedgerIntegrityError): ledger.verify()

    def test_extract_json(self):
        self.assertEqual(extract_json("```json\n{\"action\":\"finish\"}\n```"), {"action":"finish"})

    def test_network_denied(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = ScriptedModel([{"action":"network_request","arguments":{"url":"https://example.com"},"rationale":"x"}])
            rt = SovereignRuntime(workspace=tmp, ledger_path=Path(tmp)/"l.jsonl", model=model)
            result = rt.run(Task("t","no egress",{},{}))
            self.assertEqual(result["status"], "DENIED")

    def test_blind_retry_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = ScriptedModel([
                {"action":"read_text","arguments":{"path":"missing"},"rationale":"first"},
                {"action":"read_text","arguments":{"path":"missing"},"rationale":"again"},
            ])
            rt = SovereignRuntime(workspace=tmp, ledger_path=Path(tmp)/"l.jsonl", model=model)
            result = rt.run(Task("t","read",{},{}))
            self.assertEqual(result["status"], "BLOCKED")

    def test_all_positions_recorded_in_demo(self):
        with tempfile.TemporaryDirectory() as tmp:
            model = ScriptedModel([
                {"action":"read_text","arguments":{"path":"missing"},"rationale":"create I"},
                {"action":"calculate","arguments":{"expression":"1+1"},"rationale":"recovery","recovery_basis":"missing file does not affect calculation"},
                {"action":"finish","arguments":{},"rationale":"done","finish":True},
            ])
            rt = SovereignRuntime(workspace=tmp, ledger_path=Path(tmp)/"l.jsonl", model=model)
            result = rt.run(Task("t","test",{},{}))
            self.assertEqual(result["closure_vector"], "11111")

    def test_benchmark(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_benchmark(tmp)
            self.assertTrue(result["all_pass"])
            self.assertIsNone(result["aggregate_score"])


if __name__ == "__main__":
    unittest.main()
