# Sovereign local agent

Model proposes. Policy authorizes. Ledger remembers. Actions remain reversible.
